var require = meteorInstall({"imports":{"api":{"task.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////
//                                                                   //
// imports/api/task.js                                               //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
module.export({                                                      // 1
  Tasks: function () {                                               // 1
    return Tasks;                                                    // 1
  }                                                                  // 1
});                                                                  // 1
var Mongo = void 0;                                                  // 1
module.watch(require("meteor/mongo"), {                              // 1
  Mongo: function (v) {                                              // 1
    Mongo = v;                                                       // 1
  }                                                                  // 1
}, 0);                                                               // 1
var Tasks = new Mongo.Collection('tasks');                           // 3
///////////////////////////////////////////////////////////////////////

}}},"server":{"main.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////
//                                                                   //
// server/main.js                                                    //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
module.watch(require("../imports/api/task.js"));                     // 1
///////////////////////////////////////////////////////////////////////

}}},{
  "extensions": [
    ".js",
    ".json",
    ".jsx"
  ]
});
require("./server/main.js");
//# sourceMappingURL=app.js.map
